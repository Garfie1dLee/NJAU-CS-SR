
public class KeyWord {
	private String name;
	private int ID;
	public KeyWord(String name,int ID)
	{
		this.name=name;
		this.ID=ID;
	}
	public String GetName()
	{
		return name;
	}
	public int GetID()
	{
		return ID;
	}
	public void SetName(String name)
	{
		this.name=name;
	}

}
